# Prose: JMU Parking, Smarter

The Parking Pros

# DESCRIPTION

Parking on campus at James Madison University is a constant source of stress for the student body, faculty, and staff. Despite the recent addition of multiple parking decks and lots, many still find it difficult to plan their commute in order to arrive on time to campus commitments. There are a variety of factors affecting the availability of parking around campus including: day of the week, time of day, weather, and scheduled events. Our intention is to provide an application that allows users to create more reliable and accurate travel plans based on their individual schedules and previous parking patterns.

The data for this project was obtained from JMU Parking Services, [JMU parking portal](https://flexecm.jmu.edu/ebusiness/Account/Citations), and www.climate.gov.

# CONTENTS

* [GP1: Written Proposal](proposal)
* [GP2: Schema Design](schema)
* [GP3: Example Queries](queries)
* [GP4: Web Application](webapp)
