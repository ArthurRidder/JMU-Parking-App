#!/usr/bin/env python3
"""
Extracts data from Parking Services occupancy reports.

Before running this program, convert the original xls files into a single
csv file (by exporting each worksheet tab and concatenating the results).
"""

import csv
import sys

# maps zone names to (deck, type)
ZONES = {                                          # MAX
    "CDPD Commuter Spaces":      ("CDPD", "Com"),  # 453
    "GSPD Commuter Spaces":      ("GSPD", "Com"),  # 402
    "GSPD Faculty/Staff Spaces": ("GSPD", "Fac"),  # 63
    "MSPD F/S Parking":          ("MSPD", "Fac"),  # 566
    "MSPD Hotel Guest Parking":  ("MSPD", "Gue"),  # 170
    "MSPD Hotel Valet Parking":  ("MSPD", "Val"),  # 119
    "WAPD Commuter Spaces":      ("WAPD", "Com"),  # 542
    "WAPD Faculty/Staff Spaces": ("WAPD", "Fac"),  # 223
}

def main(path):

    # open files
    src = csv.reader(open(path, 'r'))
    path = path[:-4] + "-data" + path[-4:]
    out = csv.writer(open(path, 'w'))

    # header row
    data = ["date", "time", "deck", "type", "occ"]
    out.writerow(data)

    # read input csv
    for row in src:
        # found a timestamp?
        if row[0]:
            ts = row[0]
            ix = ts.find(' ', 8)
            data[0] = ts[:ix]
            data[1] = ts[ix+1:]
        # found a zone name?
        if row[3] in ZONES:
            data[2], data[3] = ZONES[row[3]]
            data[4] = row[11]
            out.writerow(data)


if __name__ == "__main__":
    if len(sys.argv) == 2:
        main(sys.argv[1])
    else:
        print("Usage: python3 parking.py CSVFILE")
