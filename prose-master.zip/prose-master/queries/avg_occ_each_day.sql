-- What is the average parking occupancy overall for each parking deck per hour of the day in a week?
-- This query helps visualize parking lot crowdedness throughout the day
-- simmilar to how Google can tell you how busy the DMV will be on a particular day.
-- It can be displayed to the user to help them decide when they want to leave

-- SELECT Date, Time, Deck, AVG(Occupancy) from parking.csv WHERE Deck == 'Warsaw Deck' limit 10;
DROP VIEW IF EXISTS avg_occ_each_day;

CREATE VIEW avg_occ_each_day AS
	SELECT p.deck_name, p.time, ROUND(AVG(p.occupancy),2) AS average
	FROM parking as p
	GROUP BY time, deck_name
	ORDER BY deck_name, time;

ALTER VIEW avg_occ_each_day OWNER TO prose;

SELECT * FROM avg_occ_each_day;
