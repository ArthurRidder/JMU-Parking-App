-- This query finds the average occupancy of Chamions Deck for every Tuesday
-- after school resumed in January of 2018
-- Limited time frame due to limited data

DROP VIEW IF EXISTS champ_tue_avg_occ;

CREATE VIEW champ_tue_avg_occ AS
	SELECT time, ROUND(AVG(occupancy),2) AS champ_tue_avg_occ, d.capacity
	FROM parking AS p
		JOIN deckinfo AS d ON d.deck_name = p.deck_name
	WHERE EXTRACT(dow FROM date) = 2
		AND p.deck_name = 'Champions Deck'
		AND date > '2018-01-07'
	GROUP BY time, d.capacity;

ALTER VIEW champ_tue_avg_occ OWNER TO prose;

SELECT * FROM champ_tue_avg_occ;
