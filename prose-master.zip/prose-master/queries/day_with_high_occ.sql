-- For the week of 2/4/18 - 2/10/18, what day had the highest 
-- peak of parking occupancy in any parking deck?

DROP VIEW IF EXISTS day_with_high_occ;

CREATE VIEW day_with_high_occ AS

SELECT p.date, max(p.occupancy)
FROM parking AS p
WHERE p.date >= '2018-02-04'
	AND p.date <= '2018-02-10'
GROUP BY p.date
ORDER BY p.date;

ALTER VIEW day_with_high_occ OWNER TO prose;

SELECT * FROM day_with_high_occ;
