--
-- Looks at parking availability for Grace Street parking deck
-- on 2/5/2018. This query will be extended to visualize any deck,
-- time, or day.
--
-- Answers the following possible user-defined question:
-- For an arbitrary day, how many spots are available at a
-- given parking deck?
--

DROP VIEW IF EXISTS grace_occ_vac CASCADE;

CREATE VIEW grace_occ_vac AS
	SELECT p.deck_name, p.occupancy
	FROM parking AS p
	WHERE p.date = '2/5/2018'
		AND p.deck_name = 'Grace Deck'
		AND p.time = '12:00:00';

ALTER VIEW grace_occ_vac OWNER TO prose;

DROP VIEW IF EXISTS grace_perc_occ_vac CASCADE;

CREATE VIEW grace_perc_occ_vac AS
	SELECT p.deck_name AS name, p.occupancy, d.capacity,
		ROUND( ((p.occupancy * 1.0/ d.capacity) * 100), 2) AS ratio
	FROM grace_occ_vac AS p
		JOIN deckinfo AS d
			ON p.deck_name = d.deck_name;

ALTER VIEW grace_perc_occ_vac OWNER TO prose;

SELECT * FROM grace_perc_occ_vac;
