--
-- Looks at parking occupancy for the Mason parking deck on a
-- Wednesday that had precipitation.
--
-- Answers the following possible user-defined question:
-- On a Wednesday that has precipitation totals, what is the hour
-- by hour occupancy of Mason Deck compared to a Wednesday
-- without precipitation?
--

DROP VIEW IF EXISTS mason_wed_precip_occ;

CREATE VIEW mason_wed_precip_occ AS
  SELECT p.date, p.time, p.occupancy, d.capacity, w.precip
  FROM parking AS p
    JOIN weather as w ON p.date = w.date
    JOIN deckinfo AS d ON d.deck_name = p.deck_name
  WHERE EXTRACT(DOW FROM p.date) = 3
    AND p.deck_name = 'Mason Deck'
    AND w.precip > 0;

ALTER VIEW mason_wed_precip_occ OWNER TO prose;

SELECT * FROM mason_wed_precip_occ;
