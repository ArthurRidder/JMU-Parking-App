# STEPS TO CREATE DATABASE

1. Download the following CSV files stored in the schema repository above (all files less than 5 MB) or download and unzip the schema repository:
    * [deckinfo.csv](deckinfo.csv) = JMU parking deck capacity and address as given from JMU Parking Services
    * [parking.csv](parking.csv) = JMU parking deck occupancy for 2018 and 2020 as given from JMU Parking Services
    * For most up-to-date JMU parking deck data, contact JMU Parking Services at parkingservices@jmu.edu or call (540) 568-3300
    * [weather.csv](weather.csv) = Weather data 2016 to 2020 provided from [climate.gov](https://www.climate.gov/maps-data/dataset/past-weather-zip-code-data-table)
    * Descriptions of column acronyms on the [weatherDataTypesExplained.PNG](weatherDataTypesExplained.PNG) screenshot
    * [citations.csv](citations.csv) = JMU citation data gathered from early 2020.

2. Run create.sql to create tables with group ownership.

3. Run copy.sh to copy data from the CSV files.

4. Run alter.sql to add PRIMARY/FOREIGN key constraints.

5. Run stats.sql to count rows and analyze the tables.
