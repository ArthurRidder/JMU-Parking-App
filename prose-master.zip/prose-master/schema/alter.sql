ALTER TABLE parking
ADD PRIMARY KEY (date, time, deck_name),
ADD FOREIGN KEY (deck_name) REFERENCES deckinfo(deck_name);

ALTER TABLE deckinfo ADD PRIMARY KEY (deck_name);

ALTER TABLE weather ADD PRIMARY KEY (date);

ALTER TABLE citation
ADD PRIMARY KEY (number, issue_date);
