#!/bin/sh

# echo COPY division FROM vdoe
# psql -c "COPY (
#     SELECT div_num, div_name
#     FROM division
#   ) TO STDOUT;" vdoe | \
#   psql -c "COPY division FROM STDIN;" absent

echo COPY weather FROM weather.csv
psql -c "\copy weather FROM weather.csv WITH CSV HEADER" prose

echo COPY parking FROM parking.csv
psql -c "\copy parking FROM parking.csv WITH CSV HEADER" prose

echo COPY deckinfo FROM deckinfo.csv
psql -c "\copy deckinfo FROM deckinfo.csv WITH CSV HEADER" prose

echo COPY citation FROM citations.csv
psql -c "\copy citation FROM citations.csv WITH CSV HEADER" prose
