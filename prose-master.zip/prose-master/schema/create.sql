DROP TABLE IF EXISTS weather;

CREATE TABLE weather (
    date date NOT NULL,
    precip float NOT NULL,
    snow float NOT NULL,
    fog int NOT NULL
);

ALTER TABLE weather OWNER TO prose;

COMMENT ON TABLE weather IS 'Daily weather information for precipictation, snow, and fog';


DROP TABLE IF EXISTS parking;

CREATE TABLE parking (
    date date NOT NULL,
    time time NOT NULL,
    deck_name varchar NOT NULL,
    occupancy int NOT NULL
);

ALTER TABLE parking OWNER TO prose;

COMMENT ON TABLE parking IS 'Information on parking occupation by location, date, and time';


DROP TABLE IF EXISTS deckinfo;

CREATE TABLE deckinfo (
    deck_name varchar NOT NULL,
    capacity int NOT NULL,
    address varchar NOT NULL
);

ALTER TABLE deckinfo OWNER TO prose;

COMMENT ON TABLE deckinfo IS 'Information on each parking deck';


DROP TABLE IF EXISTS citation;

CREATE TABLE citation (
    number integer NOT NULL,
    issue_date date NOT NULL,
    balance integer NOT NULL,
    location character varying NOT NULL
);

ALTER TABLE citation OWNER TO prose;

COMMENT ON TABLE citations IS 'Information on citations given';
