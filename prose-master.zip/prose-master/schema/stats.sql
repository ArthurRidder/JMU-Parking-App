ANALYZE VERBOSE parking;
SELECT count(*) AS prk_cnt FROM parking;

ANALYZE VERBOSE weather;
SELECT count(*) AS wtr_cnt FROM weather;

ANALYZE VERBOSE citation;
SELECT count(*) AS cit_cnt FROM citations;

ANALYZE VERBOSE deckinfo;
SELECT count(*) AS dek_cnt FROM deckinfo;
