# STEPS TO RUN WEB APPLICATION

1. To run a local Flask server, it will be easiest to install the Flask service on an Integrated Development Environment tool such as Visual Studio, found here: https://visualstudio.microsoft.com/downloads/. (For the purposes of these instructions, this is the IDE that will be used.)

2. Installing and running your own Flask virtual environment will require you to have Python installed. If you do not have Python installed on your local machine, please visit the Python website to download and install: https://www.python.org/. After both Visual Studio and Python are installed, follow the following guide to have your own virtual environment working: https://code.visualstudio.com/docs/python/tutorial-flask. Note that this virtual environment is platform-dependent and therefore we cannot include our virtual environment in this repository. 

3. After your virtual environment is set up, make sure you have our clone our "prose" our repository with the following link: https://github.com/cs374/prose.git or download the project ZIP file: https://github.com/cs374/prose/archive/master.zip. After download, open into Visual Studio, and follow this link: https://flask.palletsprojects.com/en/1.0.x/cli/ to specify that the app name is "index.py" (you may need to specify a filename path, depending on your OS). 

4. Run index.py with the Flask virtual environment and follow the link to view the web app on your local browser (default: http://127.0.0.1:5000/) and enjoy our web application!
