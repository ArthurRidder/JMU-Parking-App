# Jack Vandemeulebroecke
# Cameron Kelahan
# Kearstin Kimm
# Dylan Sullivan
# Brad Ridder
from flask import Flask, g, render_template, request, flash, url_for
import psycopg2
from os import path
from datetime import datetime

app = Flask(__name__)
app.secret_key = "123"

# returns the root homepage
@app.route("/")
def home():
    return render_template("index.html")

# returns a Waze-like "Plan a Trip" feature for a parking deck and day of week
@app.route("/when_to_leave", methods=["POST", "GET"])
def when_to_leave():    
    # 279 msec query run time on SQL view
    sql = """
    SELECT time, average
    FROM %s
    WHERE deck_name = '%s';
    """
    deck_name = request.form.get("deck_name")
    day_of_week = request.form.get("day_of_week", "")
    precipitation = request.form.get("precipitation", "")

    if not deck_name and not day_of_week:
        return render_template("when_to_leave.html")
    else:
        con = psycopg2.connect("host=localhost dbname=prose user=prose password=x6Bh49hxQ#QHE9Wh")
        cur = con.cursor()
        if precipitation == "Yes":
            cur.execute(sql % ("avg_occ_precip", deck_name,))
        else:
            cur.execute(sql % (day_of_week, deck_name,))
        
        rows = cur.fetchall()
        list = []
        for row in rows:
            time = row[0].strftime("%I:%M %p")
            row2 = row + (time,)
            list.append(row2)
        return render_template("when_to_leave.html", deck_name=deck_name, day_of_week=day_of_week, precipitation=precipitation, rows=list) 

# returns the historical statistics page to look at parking trends
@app.route("/statistics")
def statistics():
    return render_template("statistics.html")

# returns average occupancy totals of each parking deck
@app.route("/avg", methods=["POST", "GET"])
def avg():
    try:
        conn = psycopg2.connect("host=localhost dbname=prose user=prose password=x6Bh49hxQ#QHE9Wh")
    except:
        return render_template("avg.html")

    cur = conn.cursor()
    if request.method == "GET":
        cur.execute(
            # 316 msec query run time on SQL view
            """
            SELECT *
            FROM avg_occ_each_day
            """
        )
        rows = cur.fetchall()
        list = []
        for row in rows:
            time = row[1].strftime("%I:%M %p")
            row2 = row + (time,)
            list.append(row2)
    return render_template("avg.html", rows=list)

# returns occupancy for a parking deck on a given day
@app.route("/reg_occ", methods=["POST", "GET"])
def reg_occ():
    app = Flask(__name__)
    app.secret_key = 'dbN:MPOK#{&$*#()}'

    deck = request.args.get("deck")
    date = request.args.get("date")
    if not deck or not date:
        return render_template("reg_occ.html")
    else:
        conn = psycopg2.connect("host=localhost dbname=prose user=prose password=x6Bh49hxQ#QHE9Wh")
        curs = conn.cursor()

        # 232 msec query run time on SQL function
        sql = """
        SELECT *
        FROM reg_occ(%s, %s)
        ORDER BY hour;
        """
        curs.execute(sql, (date, deck,))
        rows = curs.fetchall()
        list = []
        for row in rows:
            time = row[0].strftime("%I:%M %p")
            row2 = row + (time,)
            list.append(row2)
        return render_template("reg_occ_chart.html", curs=curs, rows=list, date=date, deck=deck)

# dictionary for what day of week to use based on input
def dowSwitch(day):
    switcher = {
            0: "Sunday",
            1: "Monday",
            2: "Tuesday",
            3: "Wednesday",
            4: "Thursday",
            5: "Friday",
            6: "Saturday",
        }
    return switcher.get(day)

# returns information of parking occupancies on days with precipitation
@app.route("/precip_occ", methods=['GET','POST'])
def precip_occ():
    # 211 msec query run time on SQL function
    precip_sql = """
        SELECT *
        FROM precip(%s, %s);
        """
    
    date = request.form.get("date", "")
    deck_name = request.form.get("deck_name")
    
    if not date:
        return render_template("precip_occ.html")
    else:
        con = psycopg2.connect("host=localhost dbname=prose user=prose password=x6Bh49hxQ#QHE9Wh")
        cur = con.cursor()
        cur.execute(precip_sql, (deck_name, date,))
        rows = cur.fetchall()
        list = []
        for row in rows:
            time = row[1].strftime("%I:%M %p")
            row2 = row + (time,)
            list.append(row2)
        
        return render_template("precip_occ.html", date=date, deck_name=deck_name, rows=list) 

# returns a precentage of occupied vs vacant spaces for a deck on a day and time
@app.route("/occ_vac", methods=['GET','POST'])
def occ_vac():
    # 212 msec query run time on SQL view
    sql = """
    SELECT name, occupancy, capacity, ratio
    FROM perc_occ_vac
    WHERE name = %s
        AND date = %s
        AND time = %s;
    """
    name = request.form.get("name", "")
    date = request.form.get("date", "")
    time = request.form.get("time", "")
    
    if not name and not date and not time:
        return render_template("occ_vac.html")
    else:
        con = psycopg2.connect("host=localhost dbname=prose user=prose password=x6Bh49hxQ#QHE9Wh")
        cur = con.cursor()
        cur.execute(sql, (name, date, time,))

        rows = cur.fetchall()
        return render_template("occ_vac.html", name=name, date=date, time=time, rows=rows)

# returns the peak occupancies during a given week
@app.route("/peak_day", methods=["POST", "GET"])
def peak_day():
    # 356 msec query run time on SQL view
    sql = """
    SELECT date, max
    FROM day_with_high_occ
    WHERE date >= %s
        AND date <= %s;
    """

    start_date = request.form.get("start_date", "")
    end_date = request.form.get("end_date", "")
    
    if not start_date and not end_date:
        return render_template("peak_day.html")
    else:
        con = psycopg2.connect("host=localhost dbname=prose user=prose password=x6Bh49hxQ#QHE9Wh")
        cur = con.cursor()
        cur.execute(sql, (start_date, end_date,))

        rows = cur.fetchall()
        return render_template("peak_day.html", start_date=start_date, end_date=end_date, rows=rows)

# returns deck information including citation data
@app.route("/deck_info", methods=["POST", "GET"])
def deck_info():
    # 366 msec query run time on SQL view
    sql = """
    SELECT *
    FROM citation_count_loc
    WHERE issue_date = %s
        AND location LIKE %s;
    """

    info_sql = """
    SELECT *
    FROM deckinfo
    WHERE deck_name LIKE %s;
    """

    all_sql = """
    SELECT *
    FROM citation_count_loc
    WHERE issue_date = %s
    ORDER BY location;
    """

    dow_sql = """
    SELECT *
    FROM citations_on_dow
    """
    
    date = request.form.get("date", "")
    deck_name = request.form.get("deck_name", "")
    
    if not date and not deck_name:
        return render_template("deck_info.html")
    else:
        con = psycopg2.connect("host=localhost dbname=prose user=prose password=x6Bh49hxQ#QHE9Wh")
        cur = con.cursor()
        cur.execute(sql, (date, deck_name,))

        cus = con.cursor()
        cus.execute(info_sql, (deck_name,))

        cuo = con.cursor()
        cuo.execute(all_sql, (date,))

        curr = con.cursor()
        curr.execute(dow_sql)

        rows = cur.fetchall()
        info = cus.fetchall()
        all_cit = cuo.fetchall()
        dow_cit = curr.fetchall()
        
        list = []
        for row in dow_cit:
            dow = dowSwitch(row[0])
            row2 = row + (dow,)
            list.append(row2)
        return render_template("deck_info.html", date=date, deck_name=deck_name, rows=rows, info=info, all_cit=all_cit, dow_cit=list)
